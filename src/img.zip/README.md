azrieli_viewer.html will view the map with tile layers using leafetJS , it implements pan and zoom, the AzrieliMap.js module will be the base
and will implement the rest of the features such as routing into the map.
